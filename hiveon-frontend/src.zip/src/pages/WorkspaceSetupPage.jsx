import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import {
  getWorkspaces,
  createWorkspace,
  switchWorkspace,
} from "../api/workspaceApi";
import styles from "./WorkspaceSetupPage.module.css";

export default function WorkspaceSetupPage() {
  const navigate = useNavigate();
  const { login, workspaceId } = useAuth();

  const [workspaces, setWorkspaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const [joinCode, setJoinCode] = useState("");
const [joining, setJoining] = useState(false);


  // Redirect if workspace already selected
  useEffect(() => {
    if (workspaceId) {
      navigate("/projects", { replace: true });
    }
  }, [workspaceId, navigate]);

  // Load workspaces
  useEffect(() => {
    (async () => {
      try {
        const list = await getWorkspaces();
        setWorkspaces(list || []);
      } catch (err) {
        console.error(err);
        setError("Failed to load workspaces");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // ✅ CREATE WORKSPACE (no auto switch)
  async function handleCreate() {
    if (!newName.trim()) return;

    try {
      setCreating(true);
      setError("");

      const ws = await createWorkspace(newName.trim());
      setWorkspaces((prev) => [...prev, ws]);
      setNewName("");
    } catch (err) {
      console.error(err);
      setError("Failed to create workspace");
    } finally {
      setCreating(false);
    }
  }

// ✅ SELECT WORKSPACE (THIS WAS THE BROKEN PART)
 async function handleSelect(workspaceId) {
  try {
    const data = await switchWorkspace(workspaceId);

    login(data); // apply new JWT

    navigate("/projects", { replace: true }); // 👈 FORCE NAVIGATION
  } catch (err) {
    console.error("Workspace switch failed", err);
    setError("Failed to switch workspace");
  }
}

async function joinWorkspace() {
  if (!joinCode.trim()) return;

  try {
    setJoining(true);
    setError("");

    const res = await fetch("/api/workspace/join", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify({ code: joinCode.trim() }),
    });

    if (!res.ok) {
      const msg = await res.text();
      throw new Error(msg || "Join failed");
    }

    const data = await res.json();

    // backend returns new JWT (same pattern as switchWorkspace)
    login(data);

    navigate("/projects", { replace: true });
  } catch (err) {
    console.error(err);
    setError(err.message || "Failed to join workspace");
  } finally {
    setJoining(false);
  }
}

  return (
    <div className={styles.container}>
     <div className={styles.card}>
  {/* ICON */}
  <div className={styles.iconWrap}>
  <svg
    className={styles.hexagonIcon}
    width="56"
    height="56"
    viewBox="0 0 100 100"
    aria-hidden="true"
  >
    <polygon
      points="25,6 75,6 97,50 75,94 25,94 3,50"
      fill="none"
      stroke="#fbc02d"
      strokeWidth="6"
      strokeLinejoin="round"
    />
  </svg>
</div>

  <h1 className={styles.title}>Set up your workspace</h1>
  <p className={styles.subtitle}>
    Create, join, or select a workspace to continue.
  </p>

  {/* EXISTING WORKSPACES */}
  {loading ? (
    <div className={styles.loading}>Loading workspaces…</div>
  ) : workspaces.length > 0 ? (
    <div className={styles.list}>
      {workspaces.map((ws) => (
        <button
          key={ws.id}
          className={styles.workspaceItem}
          onClick={() => handleSelect(ws.id)}
        >
          {ws.name}
        </button>
      ))}
    </div>
  ) : (
    <div className={styles.empty}>
      You are not part of any workspace yet.
    </div>
  )}

  {/* CREATE WORKSPACE */}
  <div className={styles.section}>
    <div className={styles.createBox}>
      <input
        placeholder="New workspace name"
        value={newName}
        onChange={(e) => setNewName(e.target.value)}
        className={styles.input}
      />
      <button
        onClick={handleCreate}
        disabled={creating}
        className={styles.createBtn}
      >
        {creating ? "Creating…" : "Create workspace"}
      </button>
    </div>
  </div>

  {/* JOIN WORKSPACE */}
  <div className={styles.section}>
    <div className={styles.createBox}>
      <input
        placeholder="Enter join code (e.g. HIVE-7KQ2)"
        value={joinCode}
        onChange={(e) => setJoinCode(e.target.value)}
        className={styles.input}
      />
      <button
        onClick={joinWorkspace}
        disabled={joining}
        className={styles.createBtn}
      >
        {joining ? "Joining…" : "Join workspace"}
      </button>
    </div>
  </div>

  {error && <div className={styles.error}>{error}</div>}
</div>

      </div>
   
  );
}
