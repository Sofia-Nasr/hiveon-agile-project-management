import React, { useEffect, useState, useMemo, useCallback } from "react";
import api from "../api/apiClient";
import ProjectPicker from "../components/ProjectPicker";
import TeamPicker from "../components/TeamPicker";

import {
  DndContext,
  DragOverlay,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  useDroppable,
} from "@dnd-kit/core";

import {
  useSortable,
  SortableContext,
  verticalListSortingStrategy,
  arrayMove,
} from "@dnd-kit/sortable";

import { CSS } from "@dnd-kit/utilities";

import styles from "./BoardsPage.module.css";

// Column definitions (Jira-style)
const COLUMNS = [
  { key: "To Do", label: "To Do" },
  { key: "In Progress", label: "In Progress" },
  { key: "In Review", label: "In Review" },
  { key: "Done", label: "Done" },
  { key: "Blocked", label: "Blocked" },
];

export default function BoardsPage() {
  const [projectId, setProjectId] = useState(localStorage.getItem("currentProjectId") || "");
  const [teamId, setTeamId] = useState(null);
  const [items, setItems] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loading, setLoading] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } })
  );

  // Fetch tasks for board
  const loadBoard = useCallback(async () => {
    if (!projectId || !teamId) {
      setItems([]);
      return;
    }

    try {
      setLoading(true);
      const res = await api.get("/board", { params: { projectId, teamId } });
      setItems(res.data || []);
    } catch (err) {
      console.error("Board load failed", err?.response || err);
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [projectId, teamId]);

  useEffect(() => {
    loadBoard();
  }, [loadBoard]);

  // Group tasks by column
  const grouped = useMemo(() => {
    const map = new Map(COLUMNS.map(c => [c.key, []]));

    items.forEach(t => {
      const col = map.has(t.status) ? t.status : "To Do";
      map.get(col).push(t);
    });

    for (const c of COLUMNS) {
      map.get(c.key).sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    }

    return map;
  }, [items]);

  // Drag handlers
  function getColumnOf(id) {
    for (const col of COLUMNS) {
      if (grouped.get(col.key).find(x => x.id === id)) return col.key;
    }
    return null;
  }

  async function persistMove(id, status, order) {
    try {
      await api.patch("/board/move", { ticketId: id, status, order });
    } catch (err) {
      console.error("Move persist failed", err);
      loadBoard();
    }
  }

  return (
    <div className={styles.page}>
      {/* Top Controls */}
      <div className={styles.topBar}>
        <div className={styles.formGroup}>
          <label>Project</label>
          <ProjectPicker value={projectId} onChange={setProjectId} />
        </div>

        <div className={styles.formGroup}>
          <label>Team</label>
          <TeamPicker projectId={projectId} value={teamId} onChange={setTeamId} />
        </div>

        <button className={styles.refreshBtn} onClick={loadBoard}>Refresh</button>
      </div>

      {/* Board */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={(e) => setActiveId(e.active.id)}
        onDragCancel={() => setActiveId(null)}
        onDragEnd={(event) => {
          const { active, over } = event;
          setActiveId(null);
          if (!over) return;

          const fromCol = getColumnOf(active.id);
          const overIsCol = COLUMNS.some(c => c.key === over.id);
          const toCol = overIsCol ? over.id : getColumnOf(over.id);
          if (!fromCol || !toCol) return;

          const fromList = grouped.get(fromCol);
          const toList = grouped.get(toCol);
          const fromIndex = fromList.findIndex(i => i.id === active.id);
          
          let toIndex;
          if (overIsCol) {
            toIndex = toList.length; 
          } else {
            toIndex = toList.findIndex(i => i.id === over.id);
            if (toIndex < 0) toIndex = toList.length;
          }

          // Update UI immediately
          setItems(prev =>
            prev.map(t => {
              if (t.id === active.id)
                return { ...t, status: toCol, order: toIndex };
              return t;
            })
          );

          persistMove(active.id, toCol, toIndex);
        }}
      >
        <section className={styles.boardWrapper}>
          {COLUMNS.map(col => (
            <Column
              key={col.key}
              id={col.key}
              title={col.label}
              items={grouped.get(col.key)}
              loading={loading}
            >
              <SortableContext
                items={grouped.get(col.key).map(i => i.id)}
                strategy={verticalListSortingStrategy}
              >
                {grouped.get(col.key).length === 0 && !loading ? (
                  <div className={styles.empty}>No tasks</div>
                ) : (
                  grouped.get(col.key).map((task, index) => (
                    <SortableTask key={task.id} task={task} />
                  ))
                )}
              </SortableContext>
            </Column>
          ))}
        </section>

        <DragOverlay>
          {activeId ? (
            <div className={styles.dragOverlay}>
              Dragging…
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
    </div>
  );
}

function Column({ id, title, items, children, loading }) {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <div className={styles.column}>
      <div className={styles.columnHead}>
        <span>{title}</span>
        <span className={styles.count}>{items.length}</span>
      </div>

      <div
        ref={setNodeRef}
        className={`${styles.columnBody} ${isOver ? styles.columnBodyOver : ""}`}
      >
        {loading ? <div className={styles.loading}>Loading…</div> : children}
      </div>
    </div>
  );
}

function SortableTask({ task }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: task.id });

  return (
    <div
      ref={setNodeRef}
      {...attributes}
      {...listeners}
      className={styles.taskCard}
      style={{
        transform: CSS.Translate.toString(transform),
        transition,
        opacity: isDragging ? 0.15 : 1,
      }}
    >
      <div className={styles.taskTitle}>{task.title}</div>
      <div className={styles.taskType}>{task.type}</div>
    </div>
  );
}
