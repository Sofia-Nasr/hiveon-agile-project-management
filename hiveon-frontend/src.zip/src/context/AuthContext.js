// src/context/AuthContext.js
import React, { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext(null);

function decodeJwt(token) {
  try {
    const part = token.split(".")[1];
    if (!part) return null;

    // base64url -> base64
    const base64 = part.replace(/-/g, "+").replace(/_/g, "/");
    // pad
    const padded = base64 + "===".slice((base64.length + 3) % 4);

    return JSON.parse(atob(padded));
  } catch {
    return null;
  }
}

function getClaim(decoded, shortKey, dotNetUriKey) {
  if (!decoded) return null;
  return decoded[shortKey] ?? decoded[dotNetUriKey] ?? null;
}

export function AuthProvider({ children }) {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [workspaceId, setWorkspaceId] = useState(null);
  const [initializing, setInitializing] = useState(true);

  function applyToken(jwt) {
    const decoded = decodeJwt(jwt);
    if (!decoded?.exp) return false;

    const now = Math.floor(Date.now() / 1000);
    if (decoded.exp < now) return false;

    const role = getClaim(
      decoded,
      "role",
      "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"
    );

    const username = getClaim(
      decoded,
      "name",
      "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"
    );

    const email = getClaim(
      decoded,
      "email",
      "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"
    );

    const userId = getClaim(
      decoded,
      "nameid",
      "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"
    );

    const ws = decoded.workspaceId ?? decoded["workspaceId"] ?? null;

    setToken(jwt);
    setWorkspaceId(ws);
    if (ws) localStorage.setItem("workspaceId", ws);
    else localStorage.removeItem("workspaceId");

    setUser({
      id: userId,
      username,
      email,
      role, // ✅ NOW THIS WILL BE "ProductOwner"
      workspaceId: ws,
    });

    return true;
  }

  useEffect(() => {
    const saved = localStorage.getItem("token");
    if (saved) applyToken(saved);
    setInitializing(false);
  }, []);

  const login = (input) => {
    const jwt = typeof input === "string" ? input : input?.token;
    if (!jwt || typeof jwt !== "string") return;

    localStorage.setItem("token", jwt);
    if (!applyToken(jwt)) logout();
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("workspaceId");
    setToken(null);
    setUser(null);
    setWorkspaceId(null);
  };

  return (
    <AuthContext.Provider
      value={{
        token,
        user,
        workspaceId,
        login,
        logout,
        initializing,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
